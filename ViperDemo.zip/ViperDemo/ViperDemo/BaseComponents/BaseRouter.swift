//
//  BaseRouter.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

class BaseRouter: BaseRouterConfigurable {
    func navigate(to content: ContentType, drink: Drink) -> UIViewController { UIViewController() }
}
