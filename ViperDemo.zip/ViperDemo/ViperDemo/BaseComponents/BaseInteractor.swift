//
//  BaseInteractor.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import Combine

class BaseInteractor: ErrorAndLoaderConfigurable {
    
    @Published var error: String?
    @Published var isShowingLoader: Bool = false
    
}


extension BaseInteractor: ObservableObject { }
