//
//  BasePresenter.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit
import Combine

typealias PresenterConfigurable = BaseListenerConfigurable & BasePresenterConfigurable & ErrorAndLoaderConfigurable

class BasePresenter<Interactor>: PresenterConfigurable where Interactor: AnyObject {
    
    typealias I = Interactor
    
    var interactor: Interactor
    
    var cancellables: Set<AnyCancellable>
    
    @Published var error: String?
    @Published var isShowingLoader: Bool = false
    
    init(interactor: Interactor) {
        self.interactor = interactor
        cancellables = Set<AnyCancellable>()
        setupListener()
    }
    
    func setupListener() { }
    
}


extension BasePresenter: ObservableObject { }
