//
//  BaseView.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

class BaseView: UIView, BaseViewConfigurable {
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .backgroundColor
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupView() { }
    
}
