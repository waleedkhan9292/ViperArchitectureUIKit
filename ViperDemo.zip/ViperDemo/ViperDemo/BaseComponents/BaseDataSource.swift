//
//  BaseDataSource.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 22/07/2021.
//

import UIKit

class BaseDataSource<T>: NSObject {
    @Published var data: [T] = []
}
