//
//  ItemListInteractor.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import Combine
import Alamofire

final class ItemListInteractor: BaseInteractor {
    
    //MARK:- PUBLIC PROPERTIES
    
    //MARK:- PRIVATE PROPERTIES
    private var apiClient: ApiClientProtocol
    
    
    //MARK:- PUBLIC OBSERVERS
    @Published var dataSource: GenericTVDataSource<Drink, ItemCell>? = GenericTVDataSource()
    
    //MARK:- CONSTRUCTOR
    init(apiClient: ApiClientProtocol = ApiClient()) {
        self.apiClient = apiClient
    }
}

extension ItemListInteractor {
    
    //MARK:- PUBLIC METHODS
    func loadData() {
        loadListFromApi()
    }
    
    //MARK:- PRIVATE METHODS
    private func loadListFromApi() {
        isShowingLoader = true
        let request: APIRouter = .getDrink
        apiClient.performRequest(route: request) { [unowned self] (response: AFDataResponse<List>) in
            self.isShowingLoader = false
            switch response.result {
            case let .success(value):
                self.dataSource?.data = value.drinks
            case let .failure(error):
                self.error = error.errorDescription
            }
        }
    }
}

