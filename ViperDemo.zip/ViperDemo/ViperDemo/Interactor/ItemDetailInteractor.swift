//
//  ItemDetailInteractor.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import Combine

final class ItemDetailInteractor: BaseInteractor {
    
    //MARK:- PUBLIC PROPERTIES
    
    //MARK:- PRIVATE PROPERTIES
    
    //MARK:- PUBLIC OBSERVERS
    @Published var drink: Drink?
    
    //MARK:- CONSTRUCTOR
    init(_ drink: Drink) {
        self.drink = drink
    }
}

