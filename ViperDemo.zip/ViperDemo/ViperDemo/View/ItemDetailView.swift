//
//  ItemDetailView.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

final class ItemDetailView: BaseView {
    
    let lblID = UILabel()
    let lblName = UILabel()
    let lblInstruction = UILabel()
    
    override func setupView() {
        setupIDLabel()
        setupNameLabel()
        setupInstructionLabel()
    }
}

extension ItemDetailView {
    private func setupIDLabel() {
        
        addSubview(lblID)
        
        lblID.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            lblID.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 10),
            lblID.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 10),
            lblID.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -10)
        ])
    }
    
    private func setupNameLabel() {
        
        addSubview(lblName)
        
        lblName.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            lblName.topAnchor.constraint(equalTo: lblID.bottomAnchor, constant: 10),
            lblName.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 10),
            lblName.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -10)
        ])
    }
    
    private func setupInstructionLabel() {
        
        addSubview(lblInstruction)
        
        lblInstruction.translatesAutoresizingMaskIntoConstraints = false
        
        lblInstruction.numberOfLines = 0
        
        NSLayoutConstraint.activate([
            lblInstruction.topAnchor.constraint(equalTo: lblName.bottomAnchor, constant: 10),
            lblInstruction.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 10),
            lblInstruction.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -10)
        ])
    }
}

