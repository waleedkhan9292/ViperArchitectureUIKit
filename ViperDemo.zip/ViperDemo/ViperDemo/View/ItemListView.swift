//
//  ItemListView.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

final class ItemListView: BaseView {
    
    let uitvItemList = UITableView()
    
    override func setupView() {
        setupTableView() 
    }
}

extension ItemListView {
    private func setupTableView() {
        
        addSubview(uitvItemList)
        
        uitvItemList.backgroundColor = .clear
        
        uitvItemList.separatorStyle = .none
        
        uitvItemList.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            uitvItemList.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 10),
            uitvItemList.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -10),
            uitvItemList.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 10),
            uitvItemList.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -10)
        ])
    }
}

