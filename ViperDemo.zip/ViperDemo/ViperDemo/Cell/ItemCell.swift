//
//  ItemCell.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

final class ItemCell: BaseTVCell {
    
    let lblID = UILabel()
    let lblName = UILabel()
    let lblInstruction = UILabel()
    
    let ivArrow = UIImageView()
    
    let uvSeparator = UIView()
    
    override func setupView() {
        setupIDLabel()
        setupNameLabel()
        setupInstructionLabel()
        setupImage()
        setupSeparator()
    }
    
    override func configureCell(item: BaseTVCell.I) {
        if let item = item as? Drink {
            lblID.text = "Drink id: \(item.id)"
            lblName.text = "Drink name: \(item.name)"
            lblInstruction.text = "Drink instruction: \(item.instructions)"
        }
    }

}

extension ItemCell {
    func setupIDLabel() {
        
        addSubview(lblID)
        
        lblID.translatesAutoresizingMaskIntoConstraints = false
        
        lblID.textColor = .textColor
        
        NSLayoutConstraint.activate([
            lblID.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 20),
            lblID.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 20),
            lblID.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -20)
        ])
    }
    
    private func setupNameLabel() {
        
        addSubview(lblName)
        
        lblName.translatesAutoresizingMaskIntoConstraints = false
        
        lblName.textColor = .textColor
        
        NSLayoutConstraint.activate([
            lblName.topAnchor.constraint(equalTo: lblID.bottomAnchor, constant: 20),
            lblName.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 20),
            lblName.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -20)
        ])
    }
    
    private func setupInstructionLabel() {
        
        addSubview(lblInstruction)
        
        lblInstruction.translatesAutoresizingMaskIntoConstraints = false
        
        lblInstruction.numberOfLines = 2
        
        lblInstruction.textColor = .textColor
        
        NSLayoutConstraint.activate([
            lblInstruction.topAnchor.constraint(equalTo: lblName.bottomAnchor, constant: 20),
            lblInstruction.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor, constant: 20),
            lblInstruction.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -20)
        ])
    }
    
    private func setupImage() {
        
        addSubview(ivArrow)
        
        ivArrow.translatesAutoresizingMaskIntoConstraints = false
        
        ivArrow.image = UIImage(systemName: "chevron.compact.right")
        
        NSLayoutConstraint.activate([
            ivArrow.centerYAnchor.constraint(equalTo: lblName.centerYAnchor),
            ivArrow.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor, constant: -10),
            ivArrow.heightAnchor.constraint(equalToConstant: 20),
            ivArrow.widthAnchor.constraint(equalToConstant: 20)
        ])
    }
    
    private func setupSeparator() {
        
        addSubview(uvSeparator)
        
        uvSeparator.translatesAutoresizingMaskIntoConstraints = false
        
        uvSeparator.backgroundColor = .textColor.withAlphaComponent(0.3)
        
        NSLayoutConstraint.activate([
            uvSeparator.topAnchor.constraint(equalTo: lblInstruction.bottomAnchor, constant: 20),
            uvSeparator.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor),
            uvSeparator.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor),
            uvSeparator.heightAnchor.constraint(equalToConstant: 1.0),
            uvSeparator.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor)
        ])
    }
}
