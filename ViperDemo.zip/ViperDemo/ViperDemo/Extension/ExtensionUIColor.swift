//
//  ExtensionUIColor.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 22/07/2021.
//

import UIKit

extension UIColor {
    static var backgroundColor: UIColor {
        UIColor(named: "BackgroundColor")!
    }
    
    static var textColor: UIColor {
        UIColor(named: "TextColor")!
    }
}
