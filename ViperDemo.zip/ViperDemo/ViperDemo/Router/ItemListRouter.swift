//
//  ItemListRouter.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

final class ItemListRouter: BaseRouter {
    override func navigate(to screen: ContentType, drink: Drink) -> UIViewController {
        var controller  = UIViewController()
        switch screen {
        case .detail:
            controller = ItemDetailVC(presenter: ItemDetailPresenter(interactor: ItemDetailInteractor(drink)))
        }
        return controller
    }
}
