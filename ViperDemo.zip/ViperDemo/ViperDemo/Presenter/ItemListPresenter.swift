//
//  ItemListPresenter.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

final class ItemListPresenter: BasePresenter<ItemListInteractor> {
    //MARK:- PUBLIC PROPERTIES
    
    //MARK:- PRIVATE PROPERTIES
    private var router = ItemListRouter()
    
    //MARK:- PUBLIC OBSERVERS
    @Published var dataSource: GenericTVDataSource<Drink, ItemCell>?
    
    override func setupListener() {
        interactor.$error
            .assign(to: \.error, on: self)
            .store(in: &cancellables)
        
        interactor.$isShowingLoader
            .assign(to: \.isShowingLoader, on: self)
            .store(in: &cancellables)
        
        interactor.$dataSource
            .assign(to: \.dataSource, on: self)
            .store(in: &cancellables)
    }
}

extension ItemListPresenter {
    
    //MARK:- PUBLIC METHODS
    func loadData() {
        interactor.loadData()
    }
    
    //MARK:- ROUTER METHODS
    func navigate(to content: ContentType, index: Int,
                  navigationController: UINavigationController?) {
        guard let drink = dataSource?.data[index] else {
            print("No drink avaialble.")
            return
        }
        
        navigationController?.pushViewController(router.navigate(to: content, drink: drink), animated: true)
    }
    
    
    //MARK:- PRIVATE METHODS
}
