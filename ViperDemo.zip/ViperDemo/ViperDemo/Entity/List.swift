//
//  List.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 21/07/2021.
//

import Foundation

class List: Codable {
    var drinks: [Drink]
}
