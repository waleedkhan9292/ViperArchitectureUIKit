//
//  ItemDetailVC.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

final class ItemDetailVC: BaseVC<ItemDetailView, ItemDetailPresenter> {
    
    override func setupListener() {
        presenter.$drink.sink { [unowned self] in
            if let item = $0 {
                self.contentView.lblID.text = "Drink id: \(item.id)"
                self.contentView.lblName.text = "Drink name: \(item.name)"
                self.contentView.lblInstruction.text = "Drink instruction: \(item.instructions)"
            }
        }
        .store(in: &cancellables)
    }
}
