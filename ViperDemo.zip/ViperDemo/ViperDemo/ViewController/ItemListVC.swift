//
//  ItemListVC.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

final class ItemListVC: BaseVC<ItemListView, ItemListPresenter> {
    
    private var dataSource: GenericTVDataSource<Drink, ItemCell>?
    
    override func configureViewOnLoad() {
        title = "Item List"
        presenter.loadData()
    }
    
    override func setupListener() {
        presenter.$dataSource.sink { [unowned self] in
            if let dataSource = $0 {
                self.dataSource = dataSource
                configureTableView()
            }
        }
        .store(in: &cancellables)
        
        presenter.dataSource?.$data.sink { [unowned self] in
            _ = $0
            DispatchQueue.main.async {
                self.contentView.uitvItemList.reloadData()
            }
        }
        .store(in: &cancellables)
        
        presenter.$error.sink { [unowned self] in
            if let error = $0 {
                self.showErrorAlertView(title: "Error", description: error)
            }
        }
        .store(in: &cancellables)
        
        presenter.$isShowingLoader.sink { [unowned self] in
            $0 ? self.showLoader() : self.hideLoader()
        }
        .store(in: &cancellables)
    }
}

extension ItemListVC {
    func configureTableView() {
            contentView.uitvItemList.delegate = self
            contentView.uitvItemList.dataSource = dataSource
            contentView.uitvItemList.register(ItemCell.self, forCellReuseIdentifier: ItemCell.reuseIdentifier)
    }
}

extension ItemListVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        presenter.navigate(to: .detail,
                           index: indexPath.row,
                           navigationController: navigationController)
    }
}
