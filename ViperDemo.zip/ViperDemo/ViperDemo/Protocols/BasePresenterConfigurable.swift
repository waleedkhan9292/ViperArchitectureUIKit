//
//  BasePresenterConfigurable.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import Combine

protocol BasePresenterConfigurable {
    associatedtype I
    var interactor: I { get }
    
    var cancellables: Set<AnyCancellable> { get }
}
