//
//  BaseInteractorConfigurable.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

typealias ErrorAndLoaderConfigurable = BaseErrorConfigurable & BaseLoaderConfigurable

protocol BaseLoaderConfigurable {
    var isShowingLoader: Bool { get }
}

protocol BaseErrorConfigurable {
    var error: String? { get }
}


