//
//  BasePresenterConfigurable.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

protocol BaseListenerConfigurable {
    func setupListener()
}
