//
//  BaseRouterConfigurable.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import UIKit

protocol BaseRouterConfigurable {
    func navigate(to contnet: ContentType, drink: Drink) -> UIViewController
}
