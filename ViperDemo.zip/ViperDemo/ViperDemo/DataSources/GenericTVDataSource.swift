//
//  GenericTVDataSource.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//
//

import UIKit

final class GenericTVDataSource<Model, Cell>: BaseDataSource<Model>, UITableViewDataSource where Model: AnyObject, Cell: BaseTVCell {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: Cell.reuseIdentifier) as? Cell
        else { return UITableViewCell() }
        cell.selectionStyle = .none
        cell.configureCell(item: data[indexPath.row])
        
        return cell
    }

}

