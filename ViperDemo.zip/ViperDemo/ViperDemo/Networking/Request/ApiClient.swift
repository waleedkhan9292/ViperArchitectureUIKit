//
//  ApiClient.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import Alamofire
import Foundation

final class ApiClient: ApiClientProtocol {
    
    var sessionManager: Session = {
        let configuration = URLSessionConfiguration.default
        configuration.httpAdditionalHeaders = HTTPHeaders.default.dictionary
        configuration.timeoutIntervalForRequest = TimeInterval(60)
        configuration.timeoutIntervalForResource = TimeInterval(60)
        configuration.requestCachePolicy = NSURLRequest.CachePolicy.reloadRevalidatingCacheData
        configuration.httpCookieStorage = nil
        
        var trustedPolicy: ServerTrustManager?
        let sessionManager = Session (
            configuration: configuration,
            serverTrustManager: trustedPolicy)
        
        return sessionManager
    }()
    
    func performRequest<T> (
        route: APIRouter,
        completionHandler: @escaping(AFDataResponse<T>) -> ()) where T : Decodable {
        sessionManager.request(route).responseObject(T.self) { response in
            completionHandler(response)
        }
    }
}
