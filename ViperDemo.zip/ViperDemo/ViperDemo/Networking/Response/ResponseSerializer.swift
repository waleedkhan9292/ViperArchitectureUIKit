//
//  ResponseSerializer.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//


import Alamofire
import Foundation

extension DataRequest {
    
    @discardableResult func responseObject<T: Decodable> (
        queue: DispatchQueue? = nil,
        _ type: T.Type,
        completionHandler: @escaping (AFDataResponse<T>) -> Void
    ) -> Self {
        let decoder = JSONDecoder()
        return responseDecodable(
            of: T.self,
            queue: queue ?? .main,
            decoder: decoder,
            completionHandler: completionHandler
        )
    }
}
