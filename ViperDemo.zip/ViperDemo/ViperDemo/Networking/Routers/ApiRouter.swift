//
//  ApiRouter.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//


import Alamofire
import Foundation

// APIRouter Enum to create request

enum APIRouter: URLRequestConvertible {
    
    case getDrink
    
    // MARK: - APIPath
    private var apiJson: String {
        "/api/json"
    }
    
    private var version: String {
        "/v1"
    }
    
    // MARK: - HTTPMethod
    private var method: HTTPMethod {
        switch self {
            
        case .getDrink:
            return .get
        }
    }
    
    // MARK: - Path
    private var path: String {
        switch self {
        case .getDrink:
            return "/1/search.php?s=margarita"
        }
    }
    
    // MARK: - Parameters
    private var parameters: Parameters? {
        switch self {
        case .getDrink:
            return nil
        }
    }
    
    // MARK: - URLRequestConvertible
    func asURLRequest() throws -> URLRequest {
        
        let url =  Environment.rootURL + apiJson + version
        
        var urlRequest = URLRequest(url:  URL(string: url.appending(path).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!)
        urlRequest.httpMethod = method.rawValue
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        if let parameters = parameters {
            do {
                urlRequest.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
            } catch {
                throw AFError.parameterEncodingFailed(reason: .jsonEncodingFailed(error: error))
            }
        }
        
        return urlRequest
    }
}

