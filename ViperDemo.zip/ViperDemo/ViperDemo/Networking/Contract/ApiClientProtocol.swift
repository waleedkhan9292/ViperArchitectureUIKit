//
//  ApiClientProtocol.swift
//  ViperDemo
//
//  Created by Waleed Waheed Khan on 20/07/2021.
//

import Alamofire
import Foundation


protocol ApiClientProtocol: AnyObject {
    
    var sessionManager: Session { get set }
    
    func performRequest<T>(route: APIRouter, completionHandler: @escaping (AFDataResponse<T>) -> ()) where T : Decodable
}
